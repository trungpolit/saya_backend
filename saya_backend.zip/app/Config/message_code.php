<?php

$config['message_code'] = array(
    'OrderServices' => array(
        'ord#001' => 'The data param is empty.',
        'ord#002' => 'The data param is invalid json string.',
        'ord#003' => 'The customer was banned.',
        'ord#004' => 'The cart data is empty.',
        'ord#005' => 'The order was not create successfully.',
    ),
);
