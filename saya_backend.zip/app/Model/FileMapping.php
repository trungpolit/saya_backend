<?php

class FileMapping extends AppModel {

    public $useTable = 'file_mappings';

}
