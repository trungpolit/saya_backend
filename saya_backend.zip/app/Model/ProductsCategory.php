<?php

class ProductsCategory extends AppModel {

    public $useTable = 'products_categories';

}
