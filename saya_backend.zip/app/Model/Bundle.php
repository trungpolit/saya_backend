<?php

class Bundle extends AppModel {

    public $useTable = 'bundles';
    public $actsAs = array('ManagerFilter');

}
