<?php

class Bundle extends AppModel {

    public $useTable = 'bundles';

}
