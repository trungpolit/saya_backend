<?php

class OrdersProduct extends AppModel {

    public $useTable = 'orders_products';

}
