<?php

class Role extends AppModel {

    public $useTable = 'roles';

}
