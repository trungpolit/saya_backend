<?php

class User extends AppModel {

    public $useTable = 'users';

}
