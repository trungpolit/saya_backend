<?php

class RolesPerm extends AppModel {

    public $useTable = 'roles_perms';

}
