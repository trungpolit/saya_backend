<?php

App::uses('AppController', 'Controller');

class RolesController extends AppController {

    public $uses = array('Role');

}
